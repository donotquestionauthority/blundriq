# Corresponding Source — Stockfish 19 Lite (single-threaded) WebAssembly

This archive is the Corresponding Source (GPLv3 §1, §6) for the exact engine
binary BlundrIQ conveys to the browser:

    stockfish-19-lite-single.js
        SHA-256 d3344124ab067fb0b90ee77873bb8e9fbf5fc01bc525fe714b0f942581e889e6
    stockfish-19-lite-single.wasm
        SHA-256 57ac2d72312aba346760e3f173f687a8c211208e97a87268436f7f0e10bb5387

shipped at `/engine/` for the Explore view. The binary is the unmodified
prebuilt artifact from the `stockfish` npm distribution, version 19.0.0
(npm `gitHead` 54fde71d90c7c403964f6cacef48f7bbec495df1), byte-unmodified by
BlundrIQ.

## Pinned references

- Prebuilt binary source: npm `stockfish@19.0.0`
  (https://www.npmjs.com/package/stockfish), author Nathan Rugg, sponsored by
  Chess.com.
- WASM build wrapper: `nmrugg/stockfish.js` tag `v19.0.0`
  (https://github.com/nmrugg/stockfish.js/tree/v19.0.0, commit
  `9cb3e5066d48f1a35d792afeda36eff37ae60570`) — included here under
  `nmrugg-stockfish.js/`: `build.js`, `scripts/`, the Emscripten glue under
  `src/emscripten/`, and the `src/` tree the build actually compiles. That tree
  is Stockfish 19 with the wrapper's own changes merged in, including the
  smaller mirrored piece-square feature set (`src/nnue/features/p_hm.*`) the
  Lite network needs; it is the complete source of the engine code in the
  binary. `node_modules` stripped (build dependencies, not source).
- Lite network lineage: the Stockfish 19 lite nets were produced on
  `sscg13/Stockfish` branch `sf19-1mb`
  (https://github.com/sscg13/Stockfish/tree/sf19-1mb, commit
  `f5e5c633dd0c9c0efd1d1266f441ea5929b043c1`), credited by the wrapper's
  README. Its architecture change is carried by the wrapper's `src/` above,
  which is what was compiled; that branch is therefore not duplicated here.
- Engine source: `official-stockfish/Stockfish` tag `sf_19`
  (https://github.com/official-stockfish/Stockfish/tree/sf_19, commit
  `edb0d9db6731067ec50ce619ff372b463bc4dd5d`) — included under
  `official-stockfish-Stockfish-sf_19/` as the pristine upstream the wrapper's
  tree derives from.
- Toolchain: Emscripten `3.1.7` (per `nmrugg-stockfish.js/README.md`).
- Build command for this flavor (per `nmrugg-stockfish.js/package.json`
  scripts): `node build.js --single-threaded --lite -f`.

## NNUE evaluation network (what this binary actually embeds)

Unlike 18, the 19 wrapper names both networks in `src/evaluate.h`:

    EvalFileDefaultName  "nn-1a298aa575a0.nnue"   (the standard build)
    EvalFileLiteName     "nn-61e7af4bb97d.nnue"   (Lite; aliased to the default under USE_LITE_NET)

`build.js --lite` compiles with the Lite name and embeds that one file as
`gEmbeddedNNUEData` (`build.js` `embedNet`, writing
`wasm_embedded_lite_network.h`). So the single network embedded in this binary
is **`nn-61e7af4bb97d.nnue`** (1,166,381 bytes, SHA-256
`61e7af4bb97d51eeeb25d322916f86513b5cd3a827ce189c98c6e31946f99e5b`; a Stockfish
network's file name is the first 12 hex digits of its SHA-256). The standard
network `nn-1a298aa575a0.nnue` is not embedded by this Lite binary and is not
included.

This was confirmed by inspecting the shipped WASM directly: its sole embedded
`nn-*.nnue` reference is `nn-61e7af4bb97d.nnue`, and the network bytes under
`networks/` are the bytes the WASM's data section carries, recovered from it
and verified by that SHA-256.

`nn-61e7af4bb97d.nnue` is **physically included** in this archive under
`networks/` — not merely referenced by name — so the corresponding source is
complete and self-contained, with no network fetch required to reproduce the
binary. The network is part of Stockfish and is covered by the same GNU GPL v3
as the engine.

## Reproducing the binary

1. Install Emscripten `3.1.7` and put `emcc` on PATH.
2. Use this archive's `nmrugg-stockfish.js/` build. Its `src/` is the Stockfish
   source the build compiles; place `networks/nn-61e7af4bb97d.nnue` where
   `build.js` looks for the Lite network (its `src/`), or let `build.js`
   fetch and verify it by name.
3. Run `node build.js --single-threaded --lite -f`.

## UNMODIFIED

The engine binary is the upstream prebuilt artifact, **byte-unmodified** by
BlundrIQ. BlundrIQ does not patch, recompile, or alter the engine. **If the
engine is ever modified, those modifications must be released under GPLv3 with
their corresponding source** — a hard gate on any future change to these files.

## License

Both Stockfish and Stockfish.js are GPLv3.

- `nmrugg-stockfish.js/Copying.txt` — SHA-256
  `0b383d5a63da644f628d99c33976ea6487ed89aaa59f0b3257992deac1171e6b` (byte-identical
  to the `Copying.txt` shipped alongside the binary at `/engine/`, and to the
  one in the npm tarball).
- `official-stockfish-Stockfish-sf_19/Copying.txt` — SHA-256
  `3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986` (the upstream
  Stockfish copy; the same GNU GPL v3, differing only in file formatting).
