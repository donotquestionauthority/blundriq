# Corresponding Source — Stockfish 18 Lite (single-threaded) WebAssembly

This archive is the Corresponding Source (GPLv3 §1, §6) for the exact engine
binary BlundrIQ conveys to the browser:

    stockfish-18-lite-single.js
    stockfish-18-lite-single.wasm
        SHA-256 a8fbc05ec6920b56d7485826dcb02c5ffd2826bcbf751cf973046f237a9096f1

shipped at `/engine/` on blundriq.com. The binary is the unmodified prebuilt
artifact from the `stockfish` npm distribution, version 18.0.7. (The
lite-single WASM is byte-identical across npm `stockfish@18.0.0` through
`18.0.7`; this archive's `nmrugg-stockfish.js/` wrapper is the `18.0.7`
publication. The binary is byte-unmodified by BlundrIQ.)

## Pinned references

- Prebuilt binary source: npm `stockfish@18.0.7`
  (https://www.npmjs.com/package/stockfish), author Nathan Rugg, sponsored by
  Chess.com. The published binary is byte-unmodified by BlundrIQ.
- WASM build wrapper: `nmrugg/stockfish.js` (https://github.com/nmrugg/stockfish.js)
  — included here under `nmrugg-stockfish.js/`: `build.js`, `scripts/`, the
  Emscripten glue, and the `src/` tree that the build actually compiles
  (including `src/lite_nets.h`, which selects the Lite-flavor network — see
  below). `node_modules` stripped (build dependencies, not source).
- Engine source: `official-stockfish/Stockfish` tag `sf_18`
  (https://github.com/official-stockfish/Stockfish/tree/sf_18, upstream commit
  `cb3d4ee`) — included here under `official-stockfish-Stockfish-sf_18/` as the
  pristine upstream of the engine the wrapper compiles.
- Toolchain: Emscripten `3.1.7` (per `nmrugg-stockfish.js/README.md`,
  "In order to compile the engine...").
- Build command for this flavor (per nmrugg `package.json` scripts):
  `node build.js --single-threaded --lite -f`

## NNUE evaluation network (what this binary actually embeds)

This is the **Lite** flavor, and the Lite build does **not** take its network
names from `evaluate.h`. The names in `evaluate.h` —
Big `nn-c288c895ea92.nnue`, Small `nn-37f18f62d772.nnue` — are the **standard**
(non-Lite) build's networks and are NOT embedded by this binary.

nmrugg's `build.js` reads the Lite build's network names from
`nmrugg-stockfish.js/src/lite_nets.h` instead (the file's own comment notes it
exists "because make greps through evaluate.h for these strings"):

    EvalFileDefaultNameBig   = "nn-9067e33176e8.nnue"
    EvalFileDefaultNameSmall = ""

So the single network embedded in this binary is **`nn-9067e33176e8.nnue`**
(SHA-256 `9067e33176e8c5edb7aa8db6a3aedd012f84a1f39872e86357c6c2d0993f314d`; a
Stockfish network's file name is the first 12 hex of its SHA-256). The Lite
small-net slot is empty, so `build.js` embeds a 1-byte placeholder for it.

This was confirmed by inspecting the shipped WASM directly: its sole embedded
`nn-*.nnue` reference is `nn-9067e33176e8.nnue`.

`nn-9067e33176e8.nnue` is **physically included** in this archive under
`networks/` — not merely referenced by name — so the corresponding source is
complete and self-contained, with no network fetch required to reproduce the
binary. The network is part of Stockfish and is covered by the same GNU GPL v3
as the engine. The standard-build networks `nn-c288c895ea92.nnue` and
`nn-37f18f62d772.nnue` are not embedded by this Lite binary and are not included.

## Reproducing the binary

1. Install Emscripten `3.1.7` and put `emcc` on PATH.
2. Use this archive's `nmrugg-stockfish.js/` build. Its `src/` is the Stockfish
   source the build compiles, and `src/lite_nets.h` selects the Lite network
   `nn-9067e33176e8.nnue` (included under `networks/`). The pristine upstream
   `official-stockfish/Stockfish` `sf_18` tree is included under
   `official-stockfish-Stockfish-sf_18/` for reference.
3. Run `node build.js --single-threaded --lite -f`.

## UNMODIFIED (N6)

The engine binary is the upstream prebuilt artifact, **byte-unmodified** by
BlundrIQ. BlundrIQ does not patch, recompile, or alter the engine. **If the
engine is ever modified, those modifications must be released under GPLv3 with
their corresponding source** — a hard gate on any future change to these files.

## License

Both Stockfish and Stockfish.js are GPLv3.

- `nmrugg-stockfish.js/Copying.txt` — SHA-256
  `0b383d5a63da644f628d99c33976ea6487ed89aaa59f0b3257992deac1171e6b` (byte-identical
  to the `Copying.txt` shipped alongside the binary at `/engine/`).
- `official-stockfish-Stockfish-sf_18/Copying.txt` — SHA-256
  `3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986` (the upstream
  Stockfish copy; the same GNU GPL v3, differing only in file formatting).
